//abstract class for method/function

