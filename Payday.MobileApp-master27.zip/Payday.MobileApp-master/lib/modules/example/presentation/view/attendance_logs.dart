import 'package:flutter/material.dart';
class attendanceLogsScreen extends StatefulWidget {
  const attendanceLogsScreen({Key? key}) : super(key: key);

  @override
  State<attendanceLogsScreen> createState() => _attendanceLogsScreenState();
}

class _attendanceLogsScreenState extends State<attendanceLogsScreen> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
