// App Image string here

class Images {
  static String logo = 'assets/images/logo.png';
  static String payday = 'assets/images/payday.png';
  static String calendar = 'assets/images/calendar.png';
  static String mobile = 'assets/images/mobile.png';



}
