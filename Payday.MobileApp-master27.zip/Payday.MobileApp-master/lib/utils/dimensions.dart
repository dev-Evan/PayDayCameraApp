
class Dimensions{
//App Size
  static double fontSizeExtraSmall=3.0;
  static double fontSizeSmall=5.0;
  static double fontSizeDefault=8.0;
  static double fontSizeExtraDefault=12.0;
  static double fontSizeMid=14.0;
  static double fontSizeLarge=24.0;
  static double fontSizeExtraLarge=40.0;

//padding
  static double paddingExtraSmall=3.0;
  static double paddingSmall=5.0;
  static double paddingDefault=8.0;
  static double paddingExtraDefault=12.0;
  static double paddingMid=15.0;
  static double paddingLarge=20.0;
  static double paddingExtraLarge=30.0;

  // Radius
  static double radiusExtraSmall=3.0;
  static double radiusSmall=5.0;
  static double radiusDefault=8.0;
  static double radiusMid=15.0;
  static double radiusLarge=25.0;
  static double radiusExtraLarge=40.0;

}