class AppString {

  // Apps url here
  static const String BASE_URL="https://payday.php8.gainhq.com/api";
  static const String logIn="login";


  // Apps string here
  static const String exampleText = "";
 // static const String exampleText = "";




  // Route string here
  static const String splashScreen = "/splash_screen";
  static const String signInScreen = "/signIn_screen'";
  static const String forgotScreen = "/forgot_screen'";
  static const String receiveScreen = "/receive_screen'";
  static const String onboardScreen = "/onboard_screen'";




}
