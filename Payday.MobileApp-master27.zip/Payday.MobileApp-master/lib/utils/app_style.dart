import 'package:flutter/material.dart';
import 'app_color.dart';

class AppStyle {
  static const title_text = TextStyle(
    fontSize: 24,
    color: Colors.black,
    fontWeight: FontWeight.w500,
  );
}
