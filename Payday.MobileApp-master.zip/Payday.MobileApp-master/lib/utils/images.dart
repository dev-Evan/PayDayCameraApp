
// App Image string here

class Images {
  Images._();
static String app_logo="assets/images/payday_logo.png";
static String bg_no_log="assets/images/bg_no_log.png";
static String logo = 'assets/images/logo.png';
static String payday = 'assets/images/payday.png';
static String calendar = 'assets/images/calendar.png';
static String mobile = 'assets/images/mobile.png';
}
