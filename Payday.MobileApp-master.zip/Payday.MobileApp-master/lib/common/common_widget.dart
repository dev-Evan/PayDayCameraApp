import 'package:flutter/material.dart';


class CommonWidget extends StatelessWidget {
  const CommonWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

