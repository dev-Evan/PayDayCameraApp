part of 'app_pages.dart';



abstract class _Paths {
  _Paths._();
  static const HOME = '/home';

  static const splash = '/splash_screen';
  static const signIn = '/splash_screen';
}





