package com.solutions.gain.pay_day_mobile;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
